<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="page-heading">
        <h1 class="page-title">Faq Details</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>"><i class="fas fa-home"></i></a>
            </li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('faqs.index')); ?>" >Faqs</a></li>
        </ol>
    </div>
    <div class="page-content fade-in-up">
        <div class="row">
            <div class="col-md-12">
                <div class="ibox ibox-success">
                    <div class="ibox-head">
                        <div class="ibox-title"><?php echo e($faq->question); ?></div>
                    </div>
                    <div class="ibox-body"><?php echo $faq->answer; ?> </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/careservice/resources/views/faqs/view.blade.php ENDPATH**/ ?>