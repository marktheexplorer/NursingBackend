<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="brand">
        <a class="link" href="index.html">TimeTeck Admin</a>
    </div>
    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?> 
    <form id="forgot-form"  method="POST" action="<?php echo e(route('password.email')); ?>">
    <?php echo csrf_field(); ?>
        <h3 class="m-t-10 m-b-10">Forgot password</h3>
        <p class="m-b-20">Enter your email address below and we'll send you password reset link.</p>
        <div class="form-group">
            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="E-mail Address" required>
            <?php if($errors->has('email')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <button class="btn btn-info btn-block" type="submit"><?php echo e(__('Send Password Reset Link')); ?></button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/timeteck/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>