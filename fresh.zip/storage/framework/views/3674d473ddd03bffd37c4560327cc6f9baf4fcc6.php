<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- START PAGE CONTENT-->
    <div class="page-heading">
        <h1 class="page-title">Enquiry Details</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>"><i class="fas fa-home"></i></a>
            </li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('enquiries.index')); ?>" >Enquiry</a></li>
        </ol>
    </div>
    <div class="page-content fade-in-up">
        <div class="row">
            <div class="col-lg-9 col-md-8">
                <div class="ibox">
                    <div class="ibox-body">
                        <ul class="nav nav-tabs tabs-line">
                            <li class="nav-item">
                                <a class="nav-link <?php if(count($errors) == 0): ?> active <?php endif; ?> " href="#tab-1" data-toggle="tab"><i class="ti-bar-chart"></i> Details</a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane fade <?php if(count($errors) > 0): ?> '' <?php else: ?> show active <?php endif; ?>" id="tab-1">
                                <ul class="media-list media-list-divider m-0">
                                	<li class="media">
                                        <div class="media-img"><i class="far fa-user"></i></div>
                                        <div class="media-body">
                                            <div class="media-heading"><?php echo e($enquiry->name); ?> </div>
                                        </div>
                                    </li>
                                    <li class="media">
                                        <div class="media-img"><i class="far fa-envelope"></i></div>
                                        <div class="media-body">
                                            <div class="media-heading"><?php echo e($enquiry->email); ?> </div>
                                        </div>
                                    </li>
                                    <li class="media">
                                        <div class="media-img"><i class="fas fa-phone-volume"></i></div>
                                        <div class="media-body">
                                            <div class="media-heading text-warning"><?php echo e($enquiry->phone_number); ?></div>
                                        </div>
                                    </li>
                                    <li class="media">
                                        <div class="media-img"><i class="far fa-comment-alt"></i></div>
                                        <div class="media-body">
                                            <div class="media-heading"><?php echo e($enquiry->message); ?> </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="content">
  	<div id="content-header">
    	<div id="breadcrumb"> 
    		<a href="<?php echo e(route('dashboard')); ?>" title="Go to Home" class="tip-bottom"><i class="fas fa-home"></i> Home</a> 
    		<a href="<?php echo e(route('enquiries.index')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Enquiries</a> 
    		<a href="#" class="current">View Enquiry</a> 
    	</div>
    	<h1>Enquiry Details</h1>
  	</div>
  	<div class="container-fluid">
	    <hr>
	    <div class="row-fluid">
	      	<div class="span12">
	        	<div class="widget-box">
	          		<div class="widget-title"> <span class="icon"> <i class="fas fa-list-alt"></i> </span>
	           			 <h5>Details</h5>
	          		</div>
	          		<div class="widget-content"> 
	      				<table class="table table-bordered table-invoice">
		                  	<tbody>
		                    	<tr>
			                      	<td class="width30">Name :</td>
		                  			<td class="width70"><strong><?php echo e($enquiry->name); ?></strong></td>
		                    	</tr>
		                    	<tr>
		                      		<td>Phone Number :</td>
		                      		<td><strong><?php echo e($enquiry->phone_number); ?></strong></td>
		                    	</tr>
		                    	<tr>
		                      		<td>Email :</td>
		                      		<td><strong><?php echo e($enquiry->email); ?></strong></td>
		                    	</tr>
		                  		<tr>
		                  			<td class="width30">Message :</td>
		                    		<td class="width70"><?php echo e($enquiry->message); ?></td>
		                  		</tr>
		                    </tbody>
	                	</table>
	          		</div>
	        	</div>
	      	</div>
	    </div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/careservice/resources/views/enquiries/view.blade.php ENDPATH**/ ?>