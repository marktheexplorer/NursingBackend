<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- START PAGE CONTENT-->
    <div class="page-heading">
        <h1 class="page-title">Users Management</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>"><i class="fas fa-home"></i></a>
            </li>
            <li class="breadcrumb-item">Users</li>
        </ol>
    </div>
    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-content fade-in-up">
    	<a href="<?php echo e(route('users.create')); ?>"><button class="btn btn-info "><i class="fas fa-plus"></i> Add</button></a>
        <div class="ibox">
            <div class="ibox-head">
                <div class="ibox-title">Users Data</div>
            </div>
            <div class="ibox-body">
                <table class="table table-striped table-bordered table-hover" id="data-table" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>Id</th>
              				<th>Name</th>
	                  		<th>Email</th>
	                  		<th>Mobile no</th>
	                  		<th>Number Verified</th>
	                  		<th>Created At</th>
	                  		<th>Actions</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Id</th>
              				<th>Name</th>
	                  		<th>Email</th>
	                  		<th>Mobile no</th>
	                  		<th>Number Verified</th>
	                  		<th>Created At</th>
	                  		<th>Actions</th>
                        </tr>
                    </tfoot>
                    <tbody>
                 	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	            		<tr>
	            			<td><?php echo e(++$key); ?>

	              			<td><?php echo e(ucfirst($user->name)); ?></td>
	              			<td><?php echo e($user->email); ?></td>
	              			<td><?php echo e($user->mobile_number); ?></td>
	              			<td><?php if($user->mobile_number_verified==0): ?>
									Not Verified
								<?php else: ?>
									Verified
								<?php endif; ?>
							</td>
	              			<td><?php echo e(date_format(date_create($user->created_at), 'd M, y')); ?>

	              			<td>
	              				<ul class="actions-menu">
	              					<li>
	              						<a href="<?php echo e(url('admin/user/blocked/'.$user->id)); ?>">
					                    <?php if($user->is_blocked): ?>
					                    	<button type="button" class="btn-sm btn-danger btn-cir" title="Unblock"><i class="fa fa-unlock"></i></button>
					                	<?php else: ?>
					                		<button type="button" class="btn-sm btn-success btn-cir" title="Block"><i class="fa fa-ban"></i></button>
					            		<?php endif; ?>
                                        </a>
	              					</li>
	              					<li>
	              						<a href="<?php echo e(route('users.edit',['id' => $user->id])); ?>">
	              							<button class="btn-sm btn-primary btn-cir" title="Edit"><i class="fas fa-pencil-alt"></i></button>
	              						</a>
	              					</li>
	              					<li>
	              						<a href="<?php echo e(route('users.show',['id' => $user->id])); ?>">
	              							<button class="btn-sm btn-warning btn-cir" title="View"><i class="fas fa-eye"></i></button>
	              						</a>
	              					</li>
	              					<li>
	              						<form action="<?php echo e(url('/admin/users/'.$user->id)); ?>" method="POST" onsubmit="deleteUser('<?php echo e($user->id); ?>', '<?php echo e($user->name); ?>', event,this)">
	                    				<?php echo csrf_field(); ?>
	              							<button class="btn-sm btn-danger btn-cir" title="Delete"><i class="fas fa-trash-alt"></i></button>
	              						</form>
	              					</li>
	              				</ul>
	              			</td>
	            		</tr>
            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
	</div>    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<script type="text/javascript">
	$(document).ready( function () {
    	$('#data-table').DataTable();
	});

	function deleteUser(id, name, event,form)
    {
        event.preventDefault();
        swal({
            title: "Are you sure?",
            text: "You want to delete "+name+" user",
            icon: "warning",
            buttons: {
				cancel: true,
				confirm: true,
			},
            closeModal: false,
            closeModal: false,
            closeOnEsc: false,
        })
       .then((willDelete) => {
          	if (willDelete) {
                $.ajax({
                url: $(form).attr('action'),
                data: $(form).serialize(),
                type: 'DELETE',
                success: function(data) {
                    data = JSON.parse(data);
                    if(data['status']) {
                        swal({
                            title: data['message'],
                            text: "Press ok to continue",
                            icon: "success",
                            buttons: {
    							cancel: true,
    							confirm: true,
  							},
                            closeOnConfirm: false,
                            closeOnEsc: false,
                        })
                        .then((willDelete) => {
          					if (willDelete) {
                            	window.location.reload();
                            }
                            });
                        } else {
                             swal("Error", data['message'], "error");
                        }
                    }
                });
            } else {
                swal("Cancelled", name+"'s user will not be deleted.", "error");
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/timeteck/resources/views/users/index.blade.php ENDPATH**/ ?>