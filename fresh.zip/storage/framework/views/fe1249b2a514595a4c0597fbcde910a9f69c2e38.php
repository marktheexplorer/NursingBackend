<header class="header">
    <div class="page-brand">
        <a class="link" href="<?php echo e(route('dashboard')); ?>">
            <span class="brand">Time
                <span class="brand-tip">Teck Admin</span>
            </span>
            <span class="brand-mini">TT</span>
        </a>
    </div>
    <div class="flexbox flex-1">
        <ul class="nav navbar-toolbar">
            <li>
                <a class="nav-link sidebar-toggler js-sidebar-toggler"><i class="fas fa-bars"></i></a>
            </li>
        </ul>
        <ul class="nav navbar-toolbar">
            <li class="dropdown dropdown-user">
                <a class="nav-link dropdown-toggle link" data-toggle="dropdown">
                    <img src="<?php echo e(asset('admin/assets/img/admin-avatar.png')); ?>">
                    <span></span><?php echo e(ucfirst(Auth::user()->name)); ?><i class="fa fa-angle-down m-l-5"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="<?php echo e(route('profile')); ?>"><i class="fa fa-user"></i>Profile</a>
                    <a class="dropdown-item" href="<?php echo e(route('change.password')); ?>"><i class="fa fa-cog"></i>Change<br> Password</a>
                    <li class="dropdown-divider"></li>
                    <a  class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                        <i class="fa fa-power-off"></i> <?php echo e(__('Logout')); ?>

                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </ul>
            </li>
        </ul>
    </div>
</header>
<?php /**PATH /var/www/html/timeteck/resources/views/partials/top-menu.blade.php ENDPATH**/ ?>