<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e($_ENV['APP_NAME']); ?></title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

    <?php if(auth()->guard()->guest()): ?>
    <link href="<?php echo e(asset('admin/assets/css/pages/auth-light.css')); ?>" rel="stylesheet" />
    <?php endif; ?>
    <link href="<?php echo e(asset('admin/assets/css/main.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    
    <?php if(auth()->guard()->check()): ?>
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <?php endif; ?>
</head>  
<body class="<?php if(auth()->guard()->check()): ?> fixed-navbar has-animation <?php endif; ?> <?php if(auth()->guard()->guest()): ?> bg-silver-300 <?php endif; ?>">
    <div class="<?php if(auth()->guard()->check()): ?> page-wrapper <?php endif; ?>">
        <?php if(auth()->guard()->check()): ?>
            <?php echo $__env->make('partials.top-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('partials.left-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
        <footer class="page-footer">      
            <div class="to-top"><i class="fa fa-angle-double-up"></i></div>
        </footer>
    </div>
    <?php echo $__env->yieldContent('footer-scripts'); ?>
   
    <!-- Left Menu -->
    <script src="<?php echo e(asset('admin/assets/vendors/metisMenu/dist/metisMenu.min.js')); ?>" type="text/javascript"></script>
    <!-- CORE SCRIPTS-->
    <script src="<?php echo e(asset('admin/assets/js/app.min.js')); ?>" type="text/javascript"></script>
    <!-- Chart js-->
   <!--  <script src="<?php echo e(asset('admin/assets/vendors/chart.js/dist/Chart.min.js')); ?>" type="text/javascript"></script> -->

    <script>
        $('#flash-overlay-modal').modal();
    </script> 
</body>
</html>
<?php /**PATH /var/www/html/careservice/resources/views/layouts/app.blade.php ENDPATH**/ ?>