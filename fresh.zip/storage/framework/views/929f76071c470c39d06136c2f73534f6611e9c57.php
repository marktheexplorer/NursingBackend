<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- START PAGE CONTENT-->
    <div class="page-heading">
        <h1 class="page-title">Edit Faq</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>"><i class="fas fa-home"></i></a>
            </li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('faqs.index')); ?>">Faqs</a></li>
        </ol>
    </div>
    <div class="page-content fade-in-up">
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="ibox">
                    <div class="ibox-body">
                        <div class="tab-content">
                            <form action="<?php echo e(route('faqs.update', ['id' => $faq->id])); ?>" method="post" class="form-horizontal">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <label>Question</label>
                                        <input type="text" class="form-control <?php echo e($errors->has('question') ? ' is-invalid' : ''); ?>" name="question" placeholder="Enter Question" value="<?php echo e(old('question', $faq->question)); ?>" required/>
                                        <?php if($errors->has('question')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('question')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group col-md-12">
                                        <label>Answer</label>
                                        <textarea class="form-control" name="answer" rows="15"><?php echo e(old('answer', $faq->answer)); ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <div class="form-control <?php echo e($errors->has('answer') ? ' is-invalid' : ''); ?>">
                                            <?php if($errors->has('answer')): ?>
                                                <span class="invalid-feedback" role="alert" style="display:block">
                                                    <strong><?php echo e($errors->first('answer')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <button class="btn btn-info" type="submit">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    <script src='//cdn.tinymce.com/4/tinymce.min.js'></script>
    <script>
        tinymce.init({
            selector: 'textarea',
            menu: {
                view: {title: 'Enter Code', items: 'code'}
            },
            plugins: 'code, textpattern, textcolor',
            toolbar: [
                'undo redo | styleselect | bold italic | link image | alignleft aligncenter alignright alignjustify | fontselect | forecolor | backcolor'
            ],
            theme_advanced_fonts: 'Arial=arial,helvetica,sans-serif;Courier New=courier new,courier,monospace;AkrutiKndPadmini=Akpdmi-n',
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/careservice/resources/views/faqs/edit.blade.php ENDPATH**/ ?>