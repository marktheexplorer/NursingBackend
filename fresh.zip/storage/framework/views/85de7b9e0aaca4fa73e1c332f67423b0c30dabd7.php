    </div>
</div>
<?php /**PATH /var/www/html/careservice/vendor/consoletvs/charts/src/../resources/views/_partials/loader/container-bottom.blade.php ENDPATH**/ ?>