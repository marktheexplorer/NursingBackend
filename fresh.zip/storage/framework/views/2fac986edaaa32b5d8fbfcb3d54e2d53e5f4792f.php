<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="page-heading">
        <h1 class="page-title">FAQs</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>"><i class="fas fa-home"></i></a>
            </li>
            <li class="breadcrumb-item">Faqs</li>
        </ol>
    </div>
    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-content fade-in-up">
        <a href="<?php echo e(route('faqs.create')); ?>"><button class="btn btn-info "><i class="fas fa-plus"></i> Add</button></a>
        <div class="ibox">
           
            <div class="ibox-body">
                <table class="table table-striped table-bordered table-hover" id="data-table" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>Id</th>
              				<th>Title</th>
                            <th>Created At</th>
	                  		<th>Actions</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Id</th>
              				<th>Title</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </tfoot>
                    <tbody>
                 	<?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	            		<tr>
	            			<td><?php echo e(++$key); ?>

	              			<td><?php echo e($faq->question); ?></td>
                            <td><?php echo e(date_format(date_create($faq->created_at) , 'd M ,y')); ?>

	              			<td>
	              				<ul class="actions-menu">
                                    <li>
                                        <a href="<?php echo e(route('faqs.edit',['id' => $faq->id])); ?>">
                                            <button class="btn-sm btn-primary btn-cir" title="Edit"><i class="fas fa-pencil-alt"></i></button>
                                        </a>
                                    </li>
	              					<li>
	              						<a href="<?php echo e(route('faqs.show',['id' => $faq->id])); ?>">
	              							<button class="btn-sm btn-warning btn-cir" title="View"><i class="fas fa-eye"></i></button>
	              						</a>
	              					</li>
	              					<li>
	              						<form action="<?php echo e(url('/admin/faqs/'.$faq->id)); ?>" method="POST" onsubmit="deleteFaq('<?php echo e($faq->id); ?>', '<?php echo e($faq->question); ?>', event,this)">
	                    				<?php echo csrf_field(); ?>
	              							<button class="btn-sm btn-danger btn-cir" title="Delete"><i class="fas fa-trash-alt"></i></button>
	              						</form>
	              					</li>
	              				</ul>
	              			</td>
	            		</tr>
            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
	</div>    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<script type="text/javascript">
	$(document).ready( function () {
    	$('#data-table').DataTable();
	});

	function deleteFaq(id, name, event,form)
    {
        event.preventDefault();
        swal({
            title: "Are you sure?",
            text: "You want to delete "+name+" faq",
            icon: "warning",
            buttons: {
				cancel: true,
				confirm: true,
			},
            closeModal: false,
            closeModal: false,
            closeOnEsc: false,
        })
       .then((willDelete) => {
          	if (willDelete) {
                $.ajax({
                url: $(form).attr('action'),
                data: $(form).serialize(),
                type: 'DELETE',
                success: function(data) {
                    data = JSON.parse(data);
                    if(data['status']) {
                        swal({
                            title: data['message'],
                            text: "Press ok to continue",
                            icon: "success",
                            buttons: {
    							cancel: true,
    							confirm: true,
  							},
                            closeOnConfirm: false,
                            closeOnEsc: false,
                        })
                        .then((willDelete) => {
          					if (willDelete) {
                            	window.location.reload();
                            }
                            });
                        } else {
                             swal("Error", data['message'], "error");
                        }
                    }
                });
            } else {
                swal("Cancelled", name+"'s faq will not be deleted.", "error");
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/careservice/resources/views/faqs/index.blade.php ENDPATH**/ ?>