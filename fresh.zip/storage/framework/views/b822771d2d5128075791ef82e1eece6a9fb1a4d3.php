<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <!-- START PAGE CONTENT-->
    <div class="page-heading">
        <h1 class="page-title">Enquiries</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('dashboard')); ?>"><i class="fas fa-home"></i></a>
            </li>
            <li class="breadcrumb-item">Enquiries</li>
        </ol>
    </div>
    <div class="page-content fade-in-up">
        <div class="ibox">
            <div class="ibox-head">
                <div class="ibox-title">Enquiries Data</div>
            </div>
            <div class="ibox-body">
                <table class="table table-striped table-bordered table-hover" id="data-table" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>Id</th>
              				<th>Name</th>
	                  		<th>Email</th>
	                  		<th>Phone</th>
                            <th>Created At</th>
	                  		<th>Actions</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Id</th>
              				<th>Name</th>
	                  		<th>Email</th>
	                  		<th>Phone</th>
                            <th>Created At</th>
	                  		<th>Actions</th>
                        </tr>
                    </tfoot>
                    <tbody>
                 	<?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	            		<tr>
	            			<td><?php echo e(++$key); ?>

	              			<td><?php echo e(ucfirst($enquiry->name)); ?></td>
	              			<td><?php echo e($enquiry->email); ?></td>
	              			<td><?php echo e($enquiry->phone_number); ?></td>
                            <td><?php echo e(date_format(date_create($enquiry->created_at) , 'd M ,y')); ?>

	              			<td>
	              				<ul class="actions-menu">
	              					<li>
	              						<a href="<?php echo e(route('enquiries.show',['id' => $enquiry->id])); ?>">
	              							<button class="btn-sm btn-warning btn-cir" title="View"><i class="fas fa-eye"></i></button>
	              						</a>
	              					</li>
	              					<li>
	              						<form action="<?php echo e(url('/admin/enquiries/'.$enquiry->id)); ?>" method="POST" onsubmit="deleteEnquiry('<?php echo e($enquiry->id); ?>', '<?php echo e($enquiry->name); ?>', event,this)">
	                    				<?php echo csrf_field(); ?>
	              							<button class="btn-sm btn-danger btn-cir" title="Delete"><i class="fas fa-trash-alt"></i></button>
	              						</form>
	              					</li>
	              				</ul>
	              			</td>
	            		</tr>
            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
	</div>    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<script type="text/javascript">
	$(document).ready( function () {
    	$('#data-table').DataTable();
	});

	function deleteEnquiry(id, name, event,form)
    {
        event.preventDefault();
        swal({
            title: "Are you sure?",
            text: "You want to delete "+name+" enquiry",
            icon: "warning",
            buttons: {
				cancel: true,
				confirm: true,
			},
            closeModal: false,
            closeModal: false,
            closeOnEsc: false,
        })
       .then((willDelete) => {
          	if (willDelete) {
                $.ajax({
                url: $(form).attr('action'),
                data: $(form).serialize(),
                type: 'DELETE',
                success: function(data) {
                    data = JSON.parse(data);
                    if(data['status']) {
                        swal({
                            title: data['message'],
                            text: "Press ok to continue",
                            icon: "success",
                            buttons: {
    							cancel: true,
    							confirm: true,
  							},
                            closeOnConfirm: false,
                            closeOnEsc: false,
                        })
                        .then((willDelete) => {
          					if (willDelete) {
                            	window.location.reload();
                            }
                            });
                        } else {
                             swal("Error", data['message'], "error");
                        }
                    }
                });
            } else {
                swal("Cancelled", name+"'s enquiry will not be deleted.", "error");
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/timeteck/resources/views/enquiries/index.blade.php ENDPATH**/ ?>