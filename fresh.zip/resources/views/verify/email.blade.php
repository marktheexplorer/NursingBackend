@extends('layouts.app')

@section('content')
	@include('flash::message')
@endsection
